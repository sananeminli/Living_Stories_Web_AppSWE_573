package com.swe573.living_stories.Requests;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EditUser {

    private String photo;
    private String biography;
    private String password;


}
