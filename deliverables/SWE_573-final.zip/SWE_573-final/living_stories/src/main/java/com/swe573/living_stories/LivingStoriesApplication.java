package com.swe573.living_stories;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivingStoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivingStoriesApplication.class, args);
	}

}
