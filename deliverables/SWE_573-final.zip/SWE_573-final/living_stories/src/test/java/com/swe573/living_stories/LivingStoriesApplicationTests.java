package com.swe573.living_stories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivingStoriesApplicationTests {



}
