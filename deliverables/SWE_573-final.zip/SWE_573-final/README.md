# Living Stories 
![logo_kare](https://github.com/sananeminli/SWE_573/assets/57816597/7c6f76db-6038-4c24-9ffc-e3379237057f)

## Living Stories, the ultimate writing and memory-sharing app, where you can unleash your creativity and connect with others through the power of beautiful memories.
